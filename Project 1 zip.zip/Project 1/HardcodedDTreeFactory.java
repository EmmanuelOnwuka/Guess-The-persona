/**
 * @author Steven Bogaerts (starter code)
 */

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class HardcodedDTreeFactory {

    public static void main(String[] args) {
        HardcodedDTreeFactory factory = new HardcodedDTreeFactory();
        
        System.out.println("--------------------------");
        DTreeNode tree2 = factory.hardcode2PersonaTree();
        System.out.println("2-persona tree:\n" + tree2);
        
        System.out.println("--------------------------");
        DTreeNode tree4 = factory.hardcode4PersonaTree();
        System.out.println("4-persona tree:\n" + tree4);
        
        System.out.println("--------------------------");
        DTreeNode tree9 = factory.hardcode9PersonaTree();
        System.out.println("9-persona tree:\n" + tree9);
    }
    
    public DTreeNode hardcode2PersonaTree() {
        // Approach #1
        DTreeNode tie = new DTreeNode("tie", false);
        DTreeNode bear = new DTreeNode("Bear", true);
        DTreeNode tiger = new DTreeNode("Tiger", true);
        tie.setNodeForNo(bear);
        tie.setNodeForYes(tiger);
        
        /*
        // Approach #2
        DTreeNode bear = new DTreeNode("Bear", true);
        DTreeNode tiger = new DTreeNode("Tiger", true);
        DTreeNode tie = new DTreeNode("tie", false, bear, tiger);
        */
        
        return tie;
    }
    

    /***********************************************************************
     * Solution for step 7
     ***********************************************************************/
     public DTreeNode hardcode4PersonaTree()
     {
        DTreeNode clothes = new DTreeNode("clothes", false);
        DTreeNode tie = new DTreeNode("tie", false);
        DTreeNode ArmUp = new DTreeNode("ArmUp", false);
        DTreeNode dog = new DTreeNode("dog", true);
        DTreeNode unicorn = new DTreeNode("unicorn", true);
        DTreeNode bear = new DTreeNode("bear", true);
        DTreeNode tiger = new DTreeNode("tiger", true);
        clothes.setNodeForNo(ArmUp);
        clothes.setNodeForYes(tie);
        tie.setNodeForNo(bear);
        tie.setNodeForYes(tiger);
        ArmUp.setNodeForNo(dog);
        ArmUp.setNodeForYes(unicorn);
        
        return clothes;
    }
    
     public DTreeNode hardcode9PersonaTree()
     {
        DTreeNode ArmUp = new DTreeNode("ArmUp", false);
        DTreeNode clothes = new DTreeNode("clothes", false);
        DTreeNode belt = new DTreeNode("belt", false);
        DTreeNode eating = new DTreeNode("eating", false);
        DTreeNode tie = new DTreeNode("tie", false);
        DTreeNode walks = new DTreeNode("walks", false);
        DTreeNode panda = new DTreeNode("panda", true);
        DTreeNode bear = new DTreeNode("bear", true);
        DTreeNode tiger = new DTreeNode("tiger", true);
        DTreeNode tie1 = new DTreeNode("tie1", false);
        DTreeNode walks1 = new DTreeNode("walks1", false);
        DTreeNode unicorn = new DTreeNode("unicorn", true);
        DTreeNode lion = new DTreeNode("lion", true);
        DTreeNode shark = new DTreeNode("shark", true);
        DTreeNode fox = new DTreeNode("fox", true);
        DTreeNode parrot = new DTreeNode("parrot", true);
        DTreeNode dog = new DTreeNode("dog", true);
        ArmUp.setNodeForNo(clothes);
        ArmUp.setNodeForYes(belt);
        clothes.setNodeForNo(eating);
        clothes.setNodeForYes(tie);
        belt.setNodeForNo(tie1);
        belt.setNodeForYes(walks1);
        eating.setNodeForNo(walks);
        eating.setNodeForYes(panda);
        tie.setNodeForNo(bear);
        tie.setNodeForYes(tiger);
        tie1.setNodeForNo(unicorn);
        tie1.setNodeForYes(lion);
        walks1.setNodeForNo(shark);
        walks1.setNodeForYes(fox);
        walks.setNodeForNo(parrot);
        walks.setNodeForYes(dog);
        
        return ArmUp;
    }
    /***********************************************************************
     * End of solution for step 7
     ***********************************************************************/
     
    /*
     When you print your hardcoded trees, you should get:
     
        --------------------------
        2-persona tree:
        tie?
        No tie:
            Bear
        Yes tie:
            Tiger
        --------------------------
        4-persona tree:
        clothes?
        No clothes:
            armUp?
            No armUp:
                Dog
            Yes armUp:
                Unicorn
        Yes clothes:
            tie?
            No tie:
                Bear
            Yes tie:
                Tiger
        --------------------------
        9-persona tree:
        armUp?
        No armUp:
            clothes?
            No clothes:
                eating?
                No eating:
                    walks?
                    No walks:
                        Parrot
                    Yes walks:
                        Dog
                Yes eating:
                    Panda
            Yes clothes:
                tie?
                No tie:
                    Bear
                Yes tie:
                    Tiger
        Yes armUp:
            belt?
            No belt:
                tie?
                No tie:
                    Unicorn
                Yes tie:
                    Lion
            Yes belt:
                walks?
                No walks:
                    Shark
                Yes walks:
                    Fox
     */
    
}
